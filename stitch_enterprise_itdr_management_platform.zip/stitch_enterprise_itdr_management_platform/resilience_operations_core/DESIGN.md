---
name: Resilience Operations Core
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#45464d'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#76777d'
  outline-variant: '#c6c6cd'
  surface-tint: '#565e74'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#131b2e'
  on-primary-container: '#7c839b'
  inverse-primary: '#bec6e0'
  secondary: '#515f74'
  on-secondary: '#ffffff'
  secondary-container: '#d5e3fd'
  on-secondary-container: '#57657b'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#001a42'
  on-tertiary-container: '#3980f4'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dae2fd'
  primary-fixed-dim: '#bec6e0'
  on-primary-fixed: '#131b2e'
  on-primary-fixed-variant: '#3f465c'
  secondary-fixed: '#d5e3fd'
  secondary-fixed-dim: '#b9c7e0'
  on-secondary-fixed: '#0d1c2f'
  on-secondary-fixed-variant: '#3a485c'
  tertiary-fixed: '#d8e2ff'
  tertiary-fixed-dim: '#adc6ff'
  on-tertiary-fixed: '#001a42'
  on-tertiary-fixed-variant: '#004395'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  headline-xl:
    fontFamily: Inter
    fontSize: 1.75rem
    fontWeight: '700'
    lineHeight: 2.25rem
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 1.375rem
    fontWeight: '600'
    lineHeight: 1.875rem
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Inter
    fontSize: 1.125rem
    fontWeight: '600'
    lineHeight: 1.5rem
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Inter
    fontSize: 1rem
    fontWeight: '400'
    lineHeight: 1.5rem
  body-md:
    fontFamily: Inter
    fontSize: 0.875rem
    fontWeight: '400'
    lineHeight: 1.25rem
  body-sm:
    fontFamily: Inter
    fontSize: 0.75rem
    fontWeight: '400'
    lineHeight: 1rem
  label-md:
    fontFamily: Inter
    fontSize: 0.8125rem
    fontWeight: '600'
    lineHeight: 1.125rem
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Inter
    fontSize: 0.6875rem
    fontWeight: '600'
    lineHeight: 0.875rem
    letterSpacing: 0.04em
  metric-display:
    fontFamily: Inter
    fontSize: 2rem
    fontWeight: '700'
    lineHeight: 2.25rem
    letterSpacing: -0.02em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-desktop: 1.5rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1rem
  space-xl: 1.5rem
---

## Brand & Style

This design system establishes a high-assurance, precision-engineered aesthetic tailored for Enterprise IT Disaster Recovery (ITDR) and Business Continuity Management (BCM). Built specifically for risk directors, compliance officers, and infrastructure architects, the interface prioritizes immediate comprehension over decoration.

The visual style is rooted in institutional Corporate / Modern standards—evoking the structural rigor, stability, and dependability of legacy GRC platforms while modernizing visual rhythm and scannability. Information architecture is dense, structured, and audit-grade. Visual weight is communicated through precise boundary lines, explicit state chips, and high-contrast tabular metrics that allow operators to triage recovery gaps, audit timelines, and system failover readiness during high-stress operational events.

## Colors

The system relies on an institutional palette designed for prolonged analytical workflows and mission-critical alerting.

- **Foundational Surfaces & Shell:** The canvas utilizes `#F8FAFC` (Slate 50) as the underlying background, offset by `#F1F5F9` (Slate 100) for control bars, tabular headers, and nested panels. Interactive containers, data tables, and card layers rest on crisp `#FFFFFF`.
- **Primary & Secondary Tones:** The core identity is anchored by `#0F172A` (Slate 900) for high-impact navigation and prominent text, supported by `#1E293B` (Slate 800) and `#334155` (Slate 700) for sub-headers and secondary controls.
- **Structural Outlines:** Surfaces are demarcated with hairline borders using `#E2E8F0` (Slate 200) to maintain crisp data grid separation without visual clutter.
- **Status Semantics:**
  - **Pass / Compliant:** `#10B981` (Surface: `#ECFDF5`, Border: `#A7F3D0`, Foreground: `#065F46`)
  - **Warning / Review Due:** `#F59E0B` (Surface: `#FFFBEB`, Border: `#FDE68A`, Foreground: `#92400E`)
  - **Critical / RTO Breach / Fail:** `#EF4444` (Surface: `#FEF2F2`, Border: `#FECACA`, Foreground: `#991B1B`)
  - **Operational / Information:** `#3B82F6` (Surface: `#EFF6FF`, Border: `#BFDBFE`, Foreground: `#1E40AF`)

## Typography

Typography is calibrated for tabular scannability, dense multi-column layouts, and strict regulatory reporting. All elements deploy Inter with feature settings `cv02`, `cv03`, `cv04`, and `tnum` (tabular numerals) enforced across metric displays, grid cells, and compliance countdowns.

- **Headlines:** Reserved for operational views, dashboard titles, and audit log categorizations. Line heights remain tight to prevent vertical bloat.
- **Body:** Sized predominantly at `0.875rem` (`body-md`) and `0.75rem` (`body-sm`) to maximize visible information density per viewport without degrading legibility.
- **Labels & Micro-data:** Applied to column headers, compliance status tags, and attribute-value pairings. Uppercase transformation paired with positive letter spacing (`0.04em`) is strictly reserved for `label-sm` metadata headers.

## Layout & Spacing

The layout system operates on an 8px base rhythm (with 4px micro-increments), enforcing compact component densities suitable for enterprise administration consoles:

- **Grid Architecture:** Desktop views operate on a 12-column fluid grid constrained to a maximum content width of 1920px with standard 1.5rem outer margins. Large-screen workstations support an optional full-bleed fluid grid for high-capacity tabular monitors.
- **Density Profile:** Padding and element gaps remain conservative. Data table cell heights default to 36px (compact) or 44px (standard). Input controls and filter bars adhere strictly to standard heights of 32px to 36px.
- **Breakpoints:**
  - **Desktop (>= 1280px):** Full dual-pane or multi-column inspection layout (e.g., system inventory on the left, recovery procedure details on the right).
  - **Tablet / Small Desktop (768px - 1279px):** Collapsible navigation drawer, responsive grids collapse to 6 or 8 columns; master-detail switches to stacked or tabbed views.
  - **Mobile (< 768px):** Single-column stacked workflow restricted to emergency status checks and acknowledgment actions.

## Elevation & Depth

Visual separation relies primarily on sharp, low-contrast outlines and structural flat surfaces rather than floating shadows:

- **Border Rules:** Visual hierarchy is anchored by a 1px border system using `#E2E8F0` across all cards, table headers, and split-view dividers. Focused or highlighted panes transition to `#0F172A` or `#3B82F6`.
- **Surface Tiering:**
  - **Base Canvas:** `#F8FAFC` provides the foundational layer.
  - **Container Surface:** `#FFFFFF` elevates content cards, modals, and data grids above the canvas.
  - **Sub-panels & Insets:** `#F1F5F9` is used for table header rows, audit trail log strips, and read-only technical detail boxes.
- **Shadows:** Kept exceptionally restrained. Static cards feature no shadow. Modals, flyout context panels, and dropdown menus utilize a single low-diffusion shadow: `0 4px 6px -1px rgba(15, 23, 42, 0.08), 0 2px 4px -2px rgba(15, 23, 42, 0.06)`.

## Shapes

The geometric framework enforces an institutional, architectural discipline. Roundedness level `1` defines the system, providing a precise, compact corner treatment:

- **Core Radius (`0.25rem` / 4px):** Applied across all standard enterprise elements including buttons, form inputs, audit chips, table container frames, and status tags.
- **Nested Elements:** Badges and internal metric boxes retain a crisp 2px to 4px radius. 
- **Modals and Drawers (`0.5rem` / 8px):** Restricted to large overlay dialogs and side drawers to visually distinguish floating overlays from underlying structured data grids.

## Components

### Buttons
- **Primary:** Background `#0F172A`, text `#FFFFFF`, hover `#1E293B`, border 1px solid transparent. Sizing: 32px height (compact) and 36px height (default), padding `0 12px`, 4px radius. Font weight 600.
- **Secondary / Outline:** Background `#FFFFFF`, text `#0F172A`, border 1px solid `#E2E8F0`, hover background `#F8FAFC`.
- **Destructive:** Background `#EF4444`, text `#FFFFFF`, hover `#DC2626`. Used strictly for DR plan archiving or emergency failover initiation.

### Form Inputs & Selects
- **Text Inputs:** Height 32px or 36px, border 1px solid `#CBD5E1`, background `#FFFFFF`, text `#0F172A`. Active focus state: 1px solid `#0F172A` with a 1px outline offset.
- **Checkboxes & Radios:** Rigid 16px square/circle with a 1px solid `#CBD5E1` border. When selected, filled with `#0F172A` displaying a white check/dot icon.

### Status Chips & Badges
- **Specification:** Height 20px, uppercase `label-sm` font, 4px corner radius, padding `0 6px`, 1px solid border.
- **Compliant:** Text `#065F46`, background `#ECFDF5`, border `#A7F3D0`.
- **Under Review / Due Soon:** Text `#92400E`, background `#FFFBEB`, border `#FDE68A`.
- **Breach / Failed:** Text `#991B1B`, background `#FEF2F2`, border `#FECACA`.
- **Informational / Active:** Text `#1E40AF`, background `#EFF6FF`, border `#BFDBFE`.

### Data Tables (GRC Engine)
- **Header:** Height 36px, background `#F1F5F9`, bottom border 1px solid `#CBD5E1`. Column labels in `label-sm` uppercase, text `#475569`.
- **Rows:** Height 36px or 44px, background `#FFFFFF`, alternate striping optional via `#F8FAFC`, bottom border 1px solid `#E2E8F0`. Hover state `#F1F5F9`. Numeric columns right-aligned with tabular font numerals enabled.

### KPI Metric Cards
- **Structure:** Crisp white card container with a 1px solid `#E2E8F0` border. Padding `space-lg` (16px).
- **Layout:** Top section contains a muted `label-sm` category descriptor. Midsection displays `metric-display` (e.g., "99.98%" or "00:42:10 RTO"). Bottom section displays relative status chip and audit timestamp in `body-sm`.